"""Unit tests for the cleaning helpers.

Run:  python -m pytest tests/ -q

Having tests on the parsing layer is cheap and it is the part of the pipeline
most likely to be silently wrong, because a mis-parsed column produces plausible
numbers rather than an error.
"""
import math
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from src.cleaning import (                          # noqa: E402
    clean_state, is_total_column, parse_period_column, to_number,
)


class TestCleanState:
    def test_aliases(self):
        assert clean_state("Orissa") == "Odisha"
        assert clean_state("Uttaranchal") == "Uttarakhand"
        assert clean_state("Pondicherry") == "Puducherry"

    def test_strips_numbering_and_markers(self):
        assert clean_state("  1. Orissa* ") == "Odisha"
        assert clean_state("12) Kerala") == "Kerala"

    def test_case_insensitive(self):
        assert clean_state("TAMILNADU") == "Tamil Nadu"
        assert clean_state("tamil nadu") == "Tamil Nadu"

    def test_aggregate_rows_rejected(self):
        for bad in ("Total", "GRAND TOTAL", "All India", "India", " Sub Total "):
            assert clean_state(bad) is None, bad

    def test_junk_rejected(self):
        assert clean_state(None) is None
        assert clean_state("") is None
        assert clean_state("-") is None
        assert clean_state("Note: provisional") is None


class TestToNumber:
    def test_plain_numbers(self):
        assert to_number(42) == 42.0
        assert to_number("42") == 42.0

    def test_thousands_separator(self):
        assert to_number("1,234") == 1234.0
        assert to_number("12,34,567") == 1234567.0

    def test_provisional_markers(self):
        assert to_number("45*") == 45.0
        assert to_number("45 (P)") == 45.0

    def test_missing_tokens(self):
        for token in ("NA", "N/A", "-", "--", "", "Not Reported", "Nil"):
            assert math.isnan(to_number(token)), token

    def test_unparseable_is_nan(self):
        assert math.isnan(to_number("see footnote"))


class TestParsePeriodColumn:
    def test_various_formats(self):
        assert parse_period_column("Jan-2018") == (2018, 1)
        assert parse_period_column("2018_Jan") == (2018, 1)
        assert parse_period_column("January 2018") == (2018, 1)
        assert parse_period_column("SEPTEMBER-2021") == (2021, 9)

    def test_month_without_year(self):
        year, month = parse_period_column("Mar")
        assert year is None and month == 3

    def test_non_period_columns(self):
        assert parse_period_column("State/UT") == (None, None)
        assert parse_period_column("Sr. No.") == (None, None)


class TestIsTotalColumn:
    def test_detects_totals(self):
        for c in ("Total", "TOTAL", "Grand Total", "Total Cases", "Annual Total"):
            assert is_total_column(c), c

    def test_ignores_months(self):
        assert not is_total_column("Jan-2018")
        assert not is_total_column("State/UT")
