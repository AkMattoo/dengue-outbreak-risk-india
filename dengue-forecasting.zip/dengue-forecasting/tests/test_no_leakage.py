"""The most important test in the repo.

Verifies that no feature describing month t uses information from month t or
later. If this fails, every metric in the report is meaningless.

Run:  python -m pytest tests/test_no_leakage.py -q
"""
import sys
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from src import config                              # noqa: E402
from src.features import build                      # noqa: E402
from src.train import (                             # noqa: E402
    BASELINES, get_feature_cols, walk_forward_years,
)


def make_panel(n_months=120, states=("A", "B", "C")) -> pd.DataFrame:
    dates = pd.date_range("2012-01-01", periods=n_months, freq="MS")
    rng = np.random.default_rng(0)
    rows = []
    for s in states:
        for d in dates:
            n = int(rng.integers(0, 3))
            rows.append({
                "state": s, "date": d, "n_outbreaks": n,
                "cases": float(n * 20), "deaths": 0.0,
                "n_districts": n, "outbreak": int(n > 0),
            })
    return pd.DataFrame(rows)


def test_features_do_not_depend_on_the_present_or_future():
    """Corrupt every value from month t onward. Features for months strictly
    before t must be bit-for-bit unchanged. Anything that moves is leaking."""
    panel = make_panel()
    cut = np.sort(panel["date"].unique())[80]

    base = build(panel.copy())

    corrupted = panel.copy()
    mask = corrupted["date"] >= cut
    corrupted.loc[mask, ["outbreak", "n_outbreaks"]] = [1, 99]
    corrupted.loc[mask, "cases"] = 99_999.0
    after = build(corrupted)

    feats = get_feature_cols(base)
    past = base["date"] < cut

    leaking = []
    for f in feats:
        a = base.loc[past, f].to_numpy(dtype=float)
        b = after.loc[past, f].to_numpy(dtype=float)
        if not np.allclose(a, b, equal_nan=True):
            leaking.append(f)

    assert not leaking, f"these features leak future information: {leaking}"


def test_targets_look_forward():
    """target_h must equal the outbreak flag h months later, within a state."""
    df = build(make_panel(n_months=60, states=("A",)))
    df = df.sort_values("date").reset_index(drop=True)
    for h in config.HORIZONS:
        pd.testing.assert_series_equal(
            df[f"target_h{h}"], df["outbreak"].shift(-h),
            check_names=False, check_dtype=False,
        )


def test_walk_forward_years_are_the_last_years():
    df = build(make_panel(n_months=120))
    years = walk_forward_years(df)
    assert len(years) == config.N_TEST_YEARS
    assert years == sorted(years)
    assert max(years) == df["year"].max()


def test_baselines_only_see_training_data():
    """Each baseline must be computable from the training split alone and must
    return one probability in [0, 1] per test row."""
    df = build(make_panel(n_months=120))
    year = walk_forward_years(df)[0]
    train, test = df[df["year"] < year], df[df["year"] == year]

    for name, fn in BASELINES.items():
        p = np.asarray(fn(train, test), dtype=float)
        assert len(p) == len(test), f"{name} returned the wrong length"
        assert np.all((p >= 0) & (p <= 1)), f"{name} returned a value outside [0, 1]"


def test_grid_is_complete_and_deduplicated():
    """One row per state-month, no duplicates -- the panel invariant."""
    panel = make_panel()
    assert not panel.duplicated(subset=["state", "date"]).any()
    counts = panel.groupby("state")["date"].nunique()
    assert counts.nunique() == 1, "states cover different numbers of months"
