"""Run this FIRST. Look at the raw EpiClim file before trusting any code.

    python notebooks/00_inspect_raw.py

Prints shape, columns, disease labels, per-district record counts and the
sparsity numbers that justify the problem framing.
"""
import sys
from pathlib import Path

import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from src import config                                   # noqa: E402

pd.set_option("display.width", 200)
pd.set_option("display.max_columns", 40)

if not config.EPICLIM_FILE.exists():
    sys.exit(f"Missing {config.EPICLIM_FILE} -- see README.")

d = pd.read_csv(config.EPICLIM_FILE)
print("shape:", d.shape)
print("columns:", d.columns.tolist(), "\n")
print(d.head(4).to_string(), "\n")

print("records per year:"); print(d.year.value_counts().sort_index().to_string())
print("\ndisease labels:"); print(d.Disease.value_counts().head(12).to_string())

den = d[d.Disease.str.contains("dengue", case=False, na=False)]
print(f"\ndengue-related records: {len(den):,}")
print(f"districts: {den.district.nunique()}   states: {den.state_ut.nunique()}")

per_district = den.groupby(["state_ut", "district"]).size()
print(f"\nrecords per district -- median {per_district.median():.0f}, "
      f"max {per_district.max()}, districts with >=20: {(per_district >= 20).sum()}")
print("\nTHIS IS THE KEY NUMBER. A district-level weekly time series would need")
print("hundreds of records per district. It has a handful. Hence the state x")
print("month occurrence framing -- see README.")

print("\nclimate coverage on dengue rows:")
print(den[["preci", "LAI", "Temp"]].notna().mean().round(3).to_string())
print("\nNote: climate exists only on rows where an outbreak was reported, so it")
print("cannot fill the zero cells. Full-grid climate comes from Open-Meteo.")
