"""Stage 2 -- build features for the outbreak-risk model.

Run:  python -m src.features

Input : data/processed/outbreak_panel.csv
Output: data/processed/model_table.csv

THE ONE RULE
------------
A feature describing month t may only use information available at the end of
month t. Every rolling statistic is computed on a `.shift(1)` series, and every
expanding statistic is shifted too. Breaking this rule produces a model that
scores brilliantly in testing and is worthless in practice.
tests/test_no_leakage.py enforces it mechanically.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from src import config


# --------------------------------------------------------------- history

def add_history(df: pd.DataFrame) -> pd.DataFrame:
    """Past outbreak activity -- the strongest available signal.

    Dengue is endemic and spatially clustered: a state that reported an
    outbreak recently is far more likely to report one again.
    """
    g_out = df.groupby("state")["outbreak"]
    g_n = df.groupby("state")["n_outbreaks"]

    for lag in config.LAGS:
        df[f"outbreak_lag{lag}"] = g_out.shift(lag)
        df[f"n_outbreaks_lag{lag}"] = g_n.shift(lag)

    # shift(1) BEFORE rolling so the window never contains the current month
    for w in config.ROLLING_WINDOWS:
        df[f"outbreak_roll{w}"] = (
            g_out.shift(1).groupby(df["state"]).rolling(w, min_periods=1)
            .mean().reset_index(level=0, drop=True)
        )
        df[f"n_outbreaks_roll{w}"] = (
            g_n.shift(1).groupby(df["state"]).rolling(w, min_periods=1)
            .sum().reset_index(level=0, drop=True)
        )

    # Months since the last reported outbreak: a compact summary of dormancy.
    def months_since(s: pd.Series) -> pd.Series:
        out, last = [], np.nan
        for i, v in enumerate(s.shift(1).to_numpy()):
            if v == 1:
                last = i
            out.append(np.nan if np.isnan(last) else i - last)
        return pd.Series(out, index=s.index)

    df["months_since_outbreak"] = (
        df.groupby("state")["outbreak"].transform(months_since)
    )
    return df


# ------------------------------------------------------------ seasonality

def add_seasonality(df: pd.DataFrame) -> pd.DataFrame:
    mo = df["date"].dt.month
    df["month"] = mo
    # sin/cos so December and January are neighbours, not opposites
    df["month_sin"] = np.sin(2 * np.pi * mo / 12.0)
    df["month_cos"] = np.cos(2 * np.pi * mo / 12.0)
    df["year"] = df["date"].dt.year
    # India's dengue season follows the monsoon
    df["is_monsoon"] = mo.isin([6, 7, 8]).astype(int)
    df["is_post_monsoon"] = mo.isin([9, 10, 11]).astype(int)
    # Surveillance was visibly disrupted in 2020-21; flagging it lets the model
    # treat those years as different rather than as a real decline in disease.
    df["is_covid_year"] = df["year"].isin(config.COVID_YEARS).astype(int)
    return df


def add_climatology(df: pd.DataFrame) -> pd.DataFrame:
    """Each state's historical outbreak rate for this calendar month.

    Computed with an EXPANDING mean over prior years only -- using the whole
    history would leak the test period into training. This doubles as the
    seasonal-climatology baseline the models must beat.
    """
    df = df.sort_values(["state", "month", "date"]).copy()
    df["state_month_climatology"] = (
        df.groupby(["state", "month"])["outbreak"]
          .transform(lambda s: s.shift(1).expanding(min_periods=1).mean())
    )
    df["state_base_rate"] = (
        df.sort_values(["state", "date"])
          .groupby("state")["outbreak"]
          .transform(lambda s: s.shift(1).expanding(min_periods=6).mean())
    )
    return df.sort_values(["state", "date"]).reset_index(drop=True)


# --------------------------------------------------------------- context

def add_static(df: pd.DataFrame) -> pd.DataFrame:
    """Population and density -- dengue is an urban disease."""
    if not config.POPULATION_FILE.exists():
        print("  state_population.csv not found -- run: python -m src.prepare_population")
        return df

    pop = pd.read_csv(config.POPULATION_FILE)
    pop.columns = [c.strip().lower() for c in pop.columns]
    cols = ["state"] + [c for c in ("population", "density", "growth_rate")
                        if c in pop.columns]
    df = df.merge(pop[cols], on="state", how="left")

    if "population" in df:
        df["log_population"] = np.log1p(df["population"])
    if "density" in df:
        # Aedes aegypti breeds in stored water in dense settlements, so density
        # carries real signal rather than being a mere scale factor.
        df["log_density"] = np.log1p(df["density"])

    missing = sorted(df.loc[df["population"].isna(), "state"].unique())
    if missing:
        print(f"  no population match for: {missing}")
        print("   -> add these spellings to STATE_ALIASES in src/cleaning.py")
    else:
        print(f"  population matched for all {df['state'].nunique()} states")
    return df


def add_climate(df: pd.DataFrame) -> pd.DataFrame:
    """Lagged temperature / rainfall / humidity, if available.

    EpiClim carries climate only on rows where an outbreak was reported, so it
    cannot fill the zero cells. Climate for the full grid therefore comes from
    Open-Meteo:  python -m src.derive_state_coords && python -m src.fetch_climate

    The model runs without it; these are the highest-value optional features.
    """
    if not config.CLIMATE_FILE.exists():
        print("  climate_monthly.csv not found -- skipping climate features.")
        print("   -> python -m src.derive_state_coords && python -m src.fetch_climate")
        return df

    clim = pd.read_csv(config.CLIMATE_FILE, parse_dates=["date"])
    df = df.merge(clim, on=["state", "date"], how="left")

    for c in ("temp_mean", "precip_sum", "humidity_mean"):
        if c not in df.columns:
            continue
        g = df.groupby("state")[c]
        for lag in config.CLIMATE_LAGS:
            df[f"{c}_lag{lag}"] = g.shift(lag)
        df[f"{c}_roll3_lag1"] = (
            g.shift(1).groupby(df["state"]).rolling(3, min_periods=2)
            .mean().reset_index(level=0, drop=True)
        )
        # Anomaly vs this state's normal for this month -- an unusually wet
        # month matters more than a merely wet one.
        norm = df.groupby(["state", "month"])[f"{c}_lag1"].transform("mean")
        df[f"{c}_anom_lag1"] = df[f"{c}_lag1"] - norm

    print(f"  merged climate ({clim['state'].nunique()} states)")
    return df


# ---------------------------------------------------------------- targets

def add_targets(df: pd.DataFrame) -> pd.DataFrame:
    """target_h = was an outbreak reported h months in the FUTURE."""
    g = df.groupby("state")["outbreak"]
    for h in config.HORIZONS:
        df[f"target_h{h}"] = g.shift(-h)
    return df


# ------------------------------------------------------------------ main

def build(panel: pd.DataFrame) -> pd.DataFrame:
    df = panel.sort_values(["state", "date"]).reset_index(drop=True)
    df = add_history(df)
    df = add_seasonality(df)
    df = add_climatology(df)
    df = add_static(df)
    df = add_climate(df)
    df = add_targets(df)
    return df


def main() -> None:
    panel = pd.read_csv(config.PROCESSED / "outbreak_panel.csv", parse_dates=["date"])
    df = build(panel)

    out = config.PROCESSED / "model_table.csv"
    df.to_csv(out, index=False)

    from src.train import get_feature_cols
    feats = get_feature_cols(df)
    print(f"\nwrote {out}  shape={df.shape}")
    print(f"{len(feats)} feature columns")
    for f in feats:
        print(f"  {f}")


if __name__ == "__main__":
    main()
