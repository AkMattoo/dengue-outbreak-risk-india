"""Metrics for probabilistic outbreak-occurrence forecasts.

Why these metrics
-----------------
Only ~13% of state-months carry a reported outbreak, so plain accuracy is
useless: predicting "never" scores 87% and is worthless. The metrics here are
chosen for imbalanced, probabilistic forecasting.

AUC-PR      Area under the precision-recall curve. The right summary for a rare
            positive class. A random model scores the base rate (~0.13), so
            AUC-PR must be read against that floor, not against 0.5.
ROC-AUC     Reported for comparability, but it flatters models on imbalanced
            data -- included with that caveat rather than as the headline.
Brier       Mean squared error of the probability itself. Rewards being
            well-calibrated, not merely well-ranked. For an early-warning
            system, a probability that means what it says is the point.
Precision@K Of the K state-months the model flags as highest risk, how many
            really reported an outbreak. This is the operational question: a
            surveillance team can only investigate so many places.
Recall@K    What fraction of all real outbreaks those K flags caught.
"""
from __future__ import annotations

import numpy as np
import pandas as pd
from sklearn.metrics import (
    average_precision_score,
    brier_score_loss,
    roc_auc_score,
)


def metrics(y_true, y_prob, k_frac: float = 0.20) -> dict:
    y_true = np.asarray(y_true, dtype=float)
    y_prob = np.asarray(y_prob, dtype=float)
    mask = ~(np.isnan(y_true) | np.isnan(y_prob))
    y_true, y_prob = y_true[mask], y_prob[mask]

    n = len(y_true)
    if n == 0 or y_true.sum() == 0:
        return {"n": n, "base_rate": np.nan, "AUC_PR": np.nan, "ROC_AUC": np.nan,
                "Brier": np.nan, "precision_at_k": np.nan, "recall_at_k": np.nan,
                "lift": np.nan}

    base = float(y_true.mean())
    y_prob = np.clip(y_prob, 0.0, 1.0)

    try:
        roc = float(roc_auc_score(y_true, y_prob))
    except ValueError:
        roc = np.nan

    k = max(1, int(round(k_frac * n)))
    top = np.argsort(-y_prob)[:k]
    hits = float(y_true[top].sum())
    prec_k = hits / k
    rec_k = hits / y_true.sum()

    return {
        "n": n,
        "base_rate": base,
        "AUC_PR": float(average_precision_score(y_true, y_prob)),
        "ROC_AUC": roc,
        "Brier": float(brier_score_loss(y_true, y_prob)),
        "precision_at_k": prec_k,
        "recall_at_k": rec_k,
        # How many times better than flagging state-months at random.
        "lift": prec_k / base if base > 0 else np.nan,
    }


def summarise(results: pd.DataFrame, baseline: str = "Seasonal climatology") -> pd.DataFrame:
    """Add skill scores relative to the climatology baseline.

    skill_auc_pr : fraction of the achievable gap above the baseline that the
                   model closes. >0 means it beats climatology.
    skill_brier  : fraction of the baseline's squared error removed.
    """
    out = []
    for h, g in results.groupby("horizon"):
        b = g.loc[g["model"] == baseline]
        b_ap = float(b["AUC_PR"].iloc[0]) if len(b) else np.nan
        b_br = float(b["Brier"].iloc[0]) if len(b) else np.nan
        g = g.copy()
        g["skill_auc_pr"] = (g["AUC_PR"] - b_ap) / (1 - b_ap) if b_ap == b_ap else np.nan
        g["skill_brier"] = 1 - g["Brier"] / b_br if b_br else np.nan
        out.append(g)
    return pd.concat(out, ignore_index=True)
