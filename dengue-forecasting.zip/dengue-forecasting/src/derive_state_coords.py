"""Derive a representative lat/lon per state from EpiClim's district coordinates.

Run:  python -m src.derive_state_coords

Output: data/raw/state_coords.csv  (state, lat, lon, n_districts)

EpiClim carries latitude and longitude for every reported district, so state
centroids can be computed from the data itself rather than typed in by hand --
which keeps the pipeline reproducible and removes a manual step.

The median is used rather than the mean: it is robust to a handful of outlying
districts and to any coordinate errors in the source.

CAVEAT worth stating in the report: these are centroids of *districts that
reported outbreaks*, not true geographic state centroids. For a large state the
climate at this point is a crude proxy for the state as a whole.
"""
from __future__ import annotations

import sys

import pandas as pd

from src import config
from src.cleaning import clean_state


def main() -> None:
    if not config.EPICLIM_FILE.exists():
        sys.exit(f"Missing {config.EPICLIM_FILE} -- see README.")

    df = pd.read_csv(config.EPICLIM_FILE)
    df["state"] = df["state_ut"].map(clean_state)
    df = df.dropna(subset=["state", "Latitude", "Longitude"])

    # One row per district first, so a district with many outbreak reports does
    # not drag the state centroid toward itself.
    per_district = (df.groupby(["state", "district"])[["Latitude", "Longitude"]]
                      .median().reset_index())

    coords = (per_district.groupby("state")
              .agg(lat=("Latitude", "median"),
                   lon=("Longitude", "median"),
                   n_districts=("district", "nunique"))
              .reset_index())

    # Sanity check: everything must land inside India's bounding box.
    bad = coords[~(coords["lat"].between(6, 38) & coords["lon"].between(67, 98))]
    if len(bad):
        print("WARNING: coordinates outside India's bounding box:")
        print(bad.to_string(index=False))
        coords = coords.drop(bad.index)

    coords[["lat", "lon"]] = coords[["lat", "lon"]].round(4)
    coords.to_csv(config.COORDS_FILE, index=False)
    print(f"wrote {config.COORDS_FILE}  ({len(coords)} states)")
    print(coords.to_string(index=False))
    print("\nNext: python -m src.fetch_climate   (needs internet, no API key)")


if __name__ == "__main__":
    main()
