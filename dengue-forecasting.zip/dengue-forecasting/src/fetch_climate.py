"""Optional stage -- fetch monthly climate per state from Open-Meteo.

Run:  python -m src.fetch_climate

Needs data/raw/state_coords.csv with columns: state,lat,lon
(one row per state -- the state capital's coordinates are fine; look them up
on a map, it takes twenty minutes and does not need to be precise).

Why bother: dengue is spread by Aedes mosquitoes, which breed in standing
water. Rainfall and temperature therefore lead case counts by roughly one to
two months. These are the strongest external predictors you can add.

The Open-Meteo archive API is free and needs no key.
"""
from __future__ import annotations

import sys
import time

import pandas as pd
import requests

from src import config


def fetch_one(lat: float, lon: float, start: str, end: str) -> pd.DataFrame:
    params = {
        "latitude": lat,
        "longitude": lon,
        "start_date": start,
        "end_date": end,
        "daily": "temperature_2m_mean,precipitation_sum,relative_humidity_2m_mean",
        "timezone": "UTC",
    }
    r = requests.get(config.OPENMETEO_ARCHIVE_URL, params=params, timeout=180)
    r.raise_for_status()
    return pd.DataFrame(r.json()["daily"])


def main() -> None:
    if not config.COORDS_FILE.exists():
        sys.exit(
            f"\nMissing {config.COORDS_FILE}.\n"
            "Create it with columns: state,lat,lon -- one row per state.\n"
            "The state capital's coordinates are close enough.\n"
        )

    coords = pd.read_csv(config.COORDS_FILE)
    coords.columns = [c.strip().lower() for c in coords.columns]

    frames = []
    for _, row in coords.iterrows():
        print(f"  fetching {row['state']}...")
        try:
            daily = fetch_one(row["lat"], row["lon"],
                              config.START_DATE, config.END_DATE[:10])
        except Exception as exc:                   # noqa: BLE001
            print(f"    failed ({exc}) -- skipping")
            continue

        daily["time"] = pd.to_datetime(daily["time"])
        daily["date"] = daily["time"].values.astype("datetime64[M]")
        monthly = daily.groupby("date").agg(
            temp_mean=("temperature_2m_mean", "mean"),
            precip_sum=("precipitation_sum", "sum"),
            humidity_mean=("relative_humidity_2m_mean", "mean"),
        ).reset_index()
        monthly["state"] = row["state"]
        frames.append(monthly)
        time.sleep(1.0)                            # be polite to a free API

    if not frames:
        sys.exit("No climate data fetched.")

    out = pd.concat(frames, ignore_index=True)
    path = config.PROCESSED / "climate_monthly.csv"
    out.to_csv(path, index=False)
    print(f"\nwrote {path}  shape={out.shape}")


if __name__ == "__main__":
    main()
