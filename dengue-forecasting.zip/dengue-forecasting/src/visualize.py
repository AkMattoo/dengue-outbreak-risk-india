"""Stage 4 -- figures for the report.

Run:  python -m src.visualize

Five figures, each answering a question the reviewer will ask:

  01 seasonality      -- do you understand the disease?
  02 data sparsity    -- do you understand the data's limits?  <- the key figure
  03 model comparison -- does anything beat the baselines?
  04 risk heatmap     -- what does the forecast actually look like?
  05 reliability      -- are the probabilities honest?
"""
from __future__ import annotations

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from src import config

# One restrained, colour-blind-safe palette across every figure, so the report
# reads as a single document rather than five unrelated charts.
INK = "#2c3e50"
PRIMARY = "#1f6f8b"
ACCENT = "#d1651a"
MUTED = "#9aa5ac"
GRID = "#e3e7ea"

plt.rcParams.update({
    "figure.dpi": 150, "savefig.dpi": 150, "font.size": 10,
    "axes.titlesize": 11, "axes.titleweight": "bold",
    "axes.labelcolor": INK, "axes.edgecolor": GRID,
    "axes.spines.top": False, "axes.spines.right": False,
    "axes.grid": True, "grid.color": GRID, "grid.linewidth": 0.8,
    "text.color": INK, "xtick.color": INK, "ytick.color": INK,
    "legend.frameon": False,
})


def _save(fig, name):
    p = config.FIGURES / name
    fig.tight_layout()
    fig.savefig(p, bbox_inches="tight")
    plt.close(fig)
    print(f"  wrote {p}")


def fig_seasonality(panel):
    fig, axes = plt.subplots(1, 2, figsize=(11, 3.6))
    ts = panel.groupby("date")["n_outbreaks"].sum()
    axes[0].plot(ts.index, ts.values, color=PRIMARY, lw=1.3)
    for y in config.COVID_YEARS:
        axes[0].axvspan(pd.Timestamp(f"{y}-01-01"), pd.Timestamp(f"{y}-12-31"),
                        color=ACCENT, alpha=0.12)
    axes[0].set_title("Reported dengue outbreaks over time (COVID years shaded)")
    axes[0].set_ylabel("Outbreaks / month")

    bym = panel.groupby(panel["date"].dt.month)["n_outbreaks"].sum()
    axes[1].bar(bym.index, bym.values, color=PRIMARY, width=0.7)
    axes[1].set_title("By calendar month — monsoon / post-monsoon peak")
    axes[1].set_xticks(range(1, 13))
    axes[1].set_xticklabels(list("JFMAMJJASOND"))
    _save(fig, "01_seasonality.png")


def fig_sparsity(panel):
    """The figure that justifies the whole problem framing."""
    fig, axes = plt.subplots(1, 2, figsize=(11, 4.0))

    act = (panel.groupby("state")["outbreak"].sum()
           .sort_values(ascending=True).tail(18))
    axes[0].barh(act.index, act.values, color=PRIMARY, height=0.72)
    axes[0].set_title("Months with a reported outbreak, by state")
    axes[0].set_xlabel(f"out of {panel['date'].nunique()} months")
    axes[0].grid(axis="y", visible=False)
    axes[0].tick_params(labelsize=8)

    rate = panel["outbreak"].mean()
    axes[1].bar(["Reported\noutbreak", "No report"], [rate, 1 - rate],
                color=[ACCENT, MUTED], width=0.55)
    axes[1].set_ylim(0, 1)
    axes[1].set_title("Class balance across all state-months")
    for i, v in enumerate([rate, 1 - rate]):
        axes[1].text(i, v + 0.02, f"{v:.1%}", ha="center", fontweight="bold")
    axes[1].grid(axis="x", visible=False)

    fig.suptitle("Data sparsity drives the problem framing", fontweight="bold", y=1.02)
    _save(fig, "02_data_sparsity.png")


def fig_model_comparison(results):
    fig, axes = plt.subplots(1, 2, figsize=(11, 3.8))
    for ax, metric, label in ((axes[0], "AUC_PR", "AUC-PR (higher is better)"),
                              (axes[1], "Brier", "Brier score (lower is better)")):
        piv = results.pivot_table(index="horizon", columns="model",
                                  values=metric, aggfunc="first")
        x = np.arange(len(piv.index))
        n = len(piv.columns)
        w = 0.8 / n
        for i, col in enumerate(piv.columns):
            is_model = col in ("LightGBM", "HistGBM", "LogisticRegression")
            ax.bar(x + i * w - 0.4 + w / 2, piv[col].values, width=w,
                   label=col, color=ACCENT if is_model else MUTED)
        ax.set_xticks(x)
        ax.set_xticklabels([f"{int(h)}m ahead" for h in piv.index])
        ax.set_title(label)
        if metric == "AUC_PR":
            base = results["base_rate"].mean()
            ax.axhline(base, color=INK, ls=":", lw=1.2)
            ax.text(0.02, base, " random floor", va="bottom", fontsize=8, color=INK)
    axes[0].legend(fontsize=7, ncol=2)
    fig.suptitle("Models vs baselines (orange = learned model)",
                 fontweight="bold", y=1.03)
    _save(fig, "03_model_comparison.png")


def fig_risk_heatmap(preds):
    h = preds["horizon"].min()
    p = preds[(preds["horizon"] == h) & (preds["model"] == preds["model"].iloc[0])]
    if p.empty:
        return
    piv = p.pivot_table(index="state", columns="date", values="prob", aggfunc="mean")
    order = piv.mean(axis=1).sort_values(ascending=False).index
    piv = piv.loc[order]

    fig, ax = plt.subplots(figsize=(11, 0.28 * len(piv) + 1.8))
    im = ax.imshow(piv.values, aspect="auto", cmap="YlOrRd", vmin=0, vmax=1)
    ax.set_yticks(range(len(piv)))
    ax.set_yticklabels(piv.index, fontsize=7)
    step = max(1, len(piv.columns) // 12)
    ax.set_xticks(range(0, len(piv.columns), step))
    ax.set_xticklabels([pd.Timestamp(d).strftime("%Y-%m")
                        for d in piv.columns[::step]], rotation=45,
                       ha="right", fontsize=7)
    ax.grid(False)
    ax.set_title(f"Predicted outbreak probability, {h} month ahead (held-out years)")
    fig.colorbar(im, ax=ax, fraction=0.02, pad=0.01, label="P(outbreak)")
    _save(fig, "04_risk_heatmap.png")


def fig_reliability(preds):
    """Are the predicted probabilities honest? A forecast of 0.3 should verify
    about 30% of the time. Ranking well is not the same as being calibrated."""
    h = preds["horizon"].min()
    fig, ax = plt.subplots(figsize=(5.2, 4.6))
    for model, colour in zip(sorted(preds["model"].unique()), (ACCENT, PRIMARY, MUTED)):
        p = preds[(preds["horizon"] == h) & (preds["model"] == model)]
        if p.empty:
            continue
        bins = np.linspace(0, min(1.0, p["prob"].max() + 1e-9), 7)
        idx = np.clip(np.digitize(p["prob"], bins) - 1, 0, len(bins) - 2)
        grp = pd.DataFrame({"b": idx, "y": p["actual"].to_numpy(),
                            "p": p["prob"].to_numpy()}).groupby("b")
        ax.plot(grp["p"].mean(), grp["y"].mean(), "o-", color=colour,
                label=model, lw=1.6, ms=4)
    ax.plot([0, 1], [0, 1], ls="--", color=INK, lw=1, label="perfect calibration")
    ax.set_xlabel("Predicted probability")
    ax.set_ylabel("Observed frequency")
    ax.set_title(f"Reliability diagram ({h} month ahead)")
    ax.legend(fontsize=8)
    _save(fig, "05_reliability.png")


def main():
    P = config.PROCESSED
    panel = pd.read_csv(P / "outbreak_panel.csv", parse_dates=["date"])
    fig_seasonality(panel)
    fig_sparsity(panel)

    if (P / "results.csv").exists():
        fig_model_comparison(pd.read_csv(P / "results.csv"))
    if (P / "predictions.csv").exists():
        preds = pd.read_csv(P / "predictions.csv", parse_dates=["date"])
        fig_risk_heatmap(preds)
        fig_reliability(preds)

    print("\nFigures in reports/figures/. Use 01, 02 and 03 in the 2-page report.")


if __name__ == "__main__":
    main()
