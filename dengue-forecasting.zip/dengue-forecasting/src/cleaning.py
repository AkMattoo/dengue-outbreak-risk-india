"""Reusable cleaners for messy Indian government tables.

Kept separate from data_prep.py so each function can be unit-tested on its own.
"""
from __future__ import annotations

import re

import numpy as np
import pandas as pd

MONTHS = {
    "jan": 1, "january": 1,
    "feb": 2, "february": 2,
    "mar": 3, "march": 3,
    "apr": 4, "april": 4,
    "may": 5,
    "jun": 6, "june": 6,
    "jul": 7, "july": 7,
    "aug": 8, "august": 8,
    "sep": 9, "sept": 9, "september": 9,
    "oct": 10, "october": 10,
    "nov": 11, "november": 11,
    "dec": 12, "december": 12,
}

# Canonical state names. Extend this dict whenever data_prep prints a name you
# do not recognise -- the keys are lowercase, the values are canonical.
STATE_ALIASES = {
    "orissa": "Odisha",
    "uttaranchal": "Uttarakhand",
    "pondicherry": "Puducherry",
    "pandicherry": "Puducherry",
    "nct of delhi": "Delhi",
    "delhi (nct)": "Delhi",
    "new delhi": "Delhi",
    "jammu & kashmir": "Jammu and Kashmir",
    "jammu and kashmir": "Jammu and Kashmir",
    "j&k": "Jammu and Kashmir",
    "a & n islands": "Andaman and Nicobar Islands",
    "a&n islands": "Andaman and Nicobar Islands",
    "andaman & nicobar islands": "Andaman and Nicobar Islands",
    "andaman and nicobar islands": "Andaman and Nicobar Islands",
    # Census 2011 writes 'Island' singular; the dengue tables write 'Islands'.
    "andaman & nicobar island": "Andaman and Nicobar Islands",
    "andaman and nicobar island": "Andaman and Nicobar Islands",
    "a & n island": "Andaman and Nicobar Islands",
    "d & n haveli": "Dadra and Nagar Haveli and Daman and Diu",
    "dadra & nagar haveli": "Dadra and Nagar Haveli and Daman and Diu",
    "daman & diu": "Dadra and Nagar Haveli and Daman and Diu",
    "dadra and nagar haveli": "Dadra and Nagar Haveli and Daman and Diu",
    "daman and diu": "Dadra and Nagar Haveli and Daman and Diu",
    "dadra nagar haveli": "Dadra and Nagar Haveli and Daman and Diu",
    "chattisgarh": "Chhattisgarh",
    "chhatisgarh": "Chhattisgarh",
    "tamilnadu": "Tamil Nadu",
    "westbengal": "West Bengal",
    "himachal pradesh ": "Himachal Pradesh",
}

# Rows that are aggregates rather than states. Keeping these double-counts
# every case in the dataset, so they must be removed.
NON_STATE_ROWS = {
    "total", "grand total", "all india", "india", "total (all india)",
    "sub total", "subtotal", "total india", "all states", "g. total",
}

# Tokens that mean "no value" in Indian government spreadsheets.
NULL_TOKENS = {
    "", "-", "--", "---", "na", "n.a.", "n/a", "nr", "not reported",
    "nil", "not available", "*", "#", ".",
}


def clean_state(name) -> str | None:
    """Normalise a state name. Returns None for aggregate/junk rows.

    >>> clean_state("  1. Orissa* ")
    'Odisha'
    >>> clean_state("Total") is None
    True
    """
    if not isinstance(name, str):
        return None
    s = name.strip()
    s = re.sub(r"^\d+[\.\)]\s*", "", s)          # strip "1. " row numbering
    s = s.strip("*#@ ").strip()
    s = re.sub(r"\s+", " ", s)
    s = re.sub(r"\s*\(.*?\)\s*$", "", s)         # strip trailing "(UT)" etc.
    key = s.lower().strip()
    if key in NON_STATE_ROWS or key in NULL_TOKENS or key.startswith("note"):
        return None
    if len(key) < 3:
        return None
    return STATE_ALIASES.get(key, s.title())


def to_number(x) -> float:
    """Coerce a government-spreadsheet cell to a float.

    Handles thousands separators, provisional markers and the many spellings
    of 'missing'.

    >>> to_number("1,234")
    1234.0
    >>> import math; math.isnan(to_number("NA"))
    True
    """
    if x is None or (isinstance(x, float) and np.isnan(x)):
        return np.nan
    if isinstance(x, (int, float, np.number)) and not isinstance(x, bool):
        return float(x)
    s = str(x).strip().replace(",", "")
    s = re.sub(r"[*#@]", "", s)
    s = re.sub(r"\(P\)|\bP\b", "", s, flags=re.IGNORECASE).strip()
    if s.lower() in NULL_TOKENS:
        return np.nan
    try:
        return float(s)
    except ValueError:
        return np.nan


def parse_period_column(col) -> tuple[int | None, int | None]:
    """Parse a column header into (year, month).

    Understands 'Jan-2018', '2018_Jan', 'January 2018', 'Jan', '2018'.
    Returns (None, None) when the header is not a period at all.

    >>> parse_period_column("Jan-2018")
    (2018, 1)
    >>> parse_period_column("State/UT")
    (None, None)
    """
    c = str(col).strip().lower()
    year = None
    m = re.search(r"(?:19|20)\d{2}", c)
    if m:
        year = int(m.group(0))
        c = c.replace(m.group(0), " ")
    letters = re.sub(r"[^a-z]+", " ", c).strip()
    month = None
    for token in letters.split():
        if token in MONTHS:
            month = MONTHS[token]
            break
        # handle 'jan18' style tokens that lost their separator
        for name, num in MONTHS.items():
            if len(name) > 2 and token.startswith(name):
                month = num
                break
        if month is not None:
            break
    return year, month


def is_total_column(col) -> bool:
    """True for 'Total' / 'Grand Total' style columns, which must be dropped."""
    c = re.sub(r"[^a-z]+", " ", str(col).strip().lower()).strip()
    return c in {"total", "grand total", "total cases", "sum", "annual total",
                 "total deaths", "cumulative"}
