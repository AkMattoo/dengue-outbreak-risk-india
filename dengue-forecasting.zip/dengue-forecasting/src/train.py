"""Stage 3 -- train and evaluate outbreak-risk models with walk-forward validation.

Run:  python -m src.train

Input : data/processed/model_table.csv
Output: data/processed/results.csv, predictions.csv, feature_importance.csv
        models/*.pkl

VALIDATION DESIGN
-----------------
Walk-forward (expanding window), not a single split. For each held-out year Y
in the final N_TEST_YEARS, the model trains on every month before January of
year Y and predicts year Y. This gives several independent out-of-sample years
instead of one, which matters enormously on a dataset this small: a single
split could land on an unusual year and tell you nothing.

Nothing from year Y or later ever reaches the training set.
"""
from __future__ import annotations

import pickle

import numpy as np
import pandas as pd

from src import config
from src.evaluate import metrics, summarise

try:
    import lightgbm as lgb
    HAVE_LGBM = True
except ImportError:                                # pragma: no cover
    HAVE_LGBM = False

from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

NON_FEATURES = {
    "state", "date", "outbreak", "n_outbreaks", "cases", "deaths",
    "n_districts", "population", "density",
}


def get_feature_cols(df: pd.DataFrame) -> list[str]:
    return [
        c for c in df.columns
        if c not in NON_FEATURES
        and not c.startswith("target")
        and pd.api.types.is_numeric_dtype(df[c])
    ]


# ------------------------------------------------------------- baselines

def baseline_climatology(train: pd.DataFrame, test: pd.DataFrame) -> np.ndarray:
    """P(outbreak) = this state's historical rate for this calendar month.

    The honest bar to beat. A model that cannot outperform "what usually
    happens here at this time of year" has added nothing.
    """
    rate = train.groupby(["state", "month"])["outbreak"].mean()
    overall = train["outbreak"].mean()
    idx = pd.MultiIndex.from_arrays([test["state"], test["month"]])
    return rate.reindex(idx).fillna(overall).to_numpy()


def baseline_persistence(train: pd.DataFrame, test: pd.DataFrame) -> np.ndarray:
    """P = 1 if this state reported an outbreak last month, else the base rate."""
    base = float(train["outbreak"].mean())
    return np.where(test["outbreak_lag1"].fillna(0) > 0, 0.9, base)


def baseline_state_rate(train: pd.DataFrame, test: pd.DataFrame) -> np.ndarray:
    """P = this state's overall historical rate. Ignores seasonality entirely."""
    rate = train.groupby("state")["outbreak"].mean()
    overall = train["outbreak"].mean()
    return test["state"].map(rate).fillna(overall).to_numpy()


def baseline_smoothed_climatology(train: pd.DataFrame, test: pd.DataFrame,
                                  alpha: float = 10.0) -> np.ndarray:
    """Empirical-Bayes shrinkage of the state x month rate toward the state rate.

        p = (positives + alpha * state_rate) / (months + alpha)

    Raw state x month cells are estimated from ~10 observations each, so they
    are extremely noisy -- which is why the cruder "state base rate" baseline
    can beat them. Shrinking each cell toward its state's overall rate keeps
    the seasonal signal where the evidence supports it and falls back to the
    state average where it does not. alpha controls how much evidence a cell
    needs before it is trusted.
    """
    grp = train.groupby(["state", "month"])["outbreak"].agg(["sum", "count"])
    state_rate = train.groupby("state")["outbreak"].mean()
    overall = float(train["outbreak"].mean())

    prior = grp.index.get_level_values("state").map(state_rate).astype(float)
    smoothed = (grp["sum"] + alpha * prior) / (grp["count"] + alpha)

    idx = pd.MultiIndex.from_arrays([test["state"], test["month"]])
    return smoothed.reindex(idx).fillna(overall).to_numpy()


BASELINES = {
    "Seasonal climatology": baseline_climatology,
    "Smoothed climatology": baseline_smoothed_climatology,
    "Persistence": baseline_persistence,
    "State base rate": baseline_state_rate,
}


# ---------------------------------------------------------------- models

def make_model(kind: str):
    if kind == "LightGBM" and HAVE_LGBM:
        return lgb.LGBMClassifier(
            n_estimators=300,
            learning_rate=0.05,
            num_leaves=15,          # kept small: ~3.7k rows, 13% positive
            min_child_samples=30,
            subsample=0.8,
            subsample_freq=1,
            colsample_bytree=0.8,
            reg_lambda=1.0,
            random_state=config.RANDOM_SEED,
            verbosity=-1,
        )
    if kind == "HistGBM":
        return HistGradientBoostingClassifier(
            max_iter=250, learning_rate=0.05, max_leaf_nodes=15,
            random_state=config.RANDOM_SEED,
        )
    # Logistic regression: a transparent, well-calibrated reference that suits a
    # small dataset and gives interpretable coefficients for the report.
    return make_pipeline(
        SimpleImputer(strategy="median"),
        StandardScaler(),
        LogisticRegression(max_iter=2000, C=0.5, random_state=config.RANDOM_SEED),
    )


def fit_predict(kind, train, test, feats, target):
    tr = train.dropna(subset=[target])
    te = test.dropna(subset=[target])
    if tr.empty or te.empty or tr[target].nunique() < 2:
        return None, te, np.array([])

    model = make_model(kind)
    X_tr, X_te = tr[feats], te[feats]
    if kind == "LightGBM":
        X_tr, X_te = X_tr.astype(float), X_te.astype(float)

    model.fit(X_tr, tr[target])
    prob = model.predict_proba(X_te)[:, 1]
    return model, te, prob


# ------------------------------------------------------------------ main

def walk_forward_years(df: pd.DataFrame) -> list[int]:
    years = sorted(df["year"].unique())
    return years[-config.N_TEST_YEARS:]


def main() -> None:
    df = pd.read_csv(config.PROCESSED / "model_table.csv", parse_dates=["date"])
    feats = get_feature_cols(df)
    test_years = walk_forward_years(df)

    model_kinds = (["LightGBM"] if HAVE_LGBM else ["HistGBM"]) + ["LogisticRegression"]

    print(f"features   : {len(feats)}")
    print(f"rows       : {len(df):,}")
    print(f"positive   : {df['outbreak'].mean():.1%}")
    print(f"test years : {test_years} (walk-forward, expanding window)\n")

    rows, preds, importances = [], [], []

    for h in config.HORIZONS:
        target = f"target_h{h}"
        # Accumulate predictions across all held-out years, then score once.
        pooled = {name: {"y": [], "p": []} for name in BASELINES}
        for k in model_kinds:
            pooled[k] = {"y": [], "p": []}

        for year in test_years:
            train = df[df["year"] < year]
            test = df[df["year"] == year]
            if train.empty or test.empty:
                continue

            te_all = test.dropna(subset=[target])
            for name, fn in BASELINES.items():
                pooled[name]["y"].append(te_all[target].to_numpy())
                pooled[name]["p"].append(fn(train, te_all))

            for kind in model_kinds:
                model, te, prob = fit_predict(kind, train, test, feats, target)
                if model is None:
                    continue
                pooled[kind]["y"].append(te[target].to_numpy())
                pooled[kind]["p"].append(prob)

                out = te[["state", "date", "outbreak", target]].copy()
                out = out.rename(columns={target: "actual"})
                out["prob"] = prob
                out["horizon"] = h
                out["model"] = kind
                out["test_year"] = year
                preds.append(out)

                if hasattr(model, "feature_importances_"):
                    importances.append(pd.DataFrame({
                        "feature": feats,
                        "importance": model.feature_importances_,
                        "horizon": h, "model": kind, "test_year": year,
                    }))
                if year == test_years[-1]:
                    with open(config.MODELS / f"{kind.lower()}_h{h}.pkl", "wb") as fh:
                        pickle.dump(model, fh)

        for name, d in pooled.items():
            if not d["y"]:
                continue
            rows.append({"model": name, "horizon": h,
                         **metrics(np.concatenate(d["y"]), np.concatenate(d["p"]))})

    results = summarise(pd.DataFrame(rows))
    results.to_csv(config.PROCESSED / "results.csv", index=False)
    if preds:
        pd.concat(preds).to_csv(config.PROCESSED / "predictions.csv", index=False)
    if importances:
        imp = pd.concat(importances)
        imp.to_csv(config.PROCESSED / "feature_importance.csv", index=False)
        top = (imp[imp["horizon"] == config.HORIZONS[0]]
               .groupby("feature")["importance"].mean()
               .sort_values(ascending=False).head(12))
        print("top features (h=%d):" % config.HORIZONS[0])
        print(top.to_string(), "\n")

    print("=" * 100)
    print("RESULTS -- pooled over held-out years. AUC-PR floor is base_rate;")
    print("skill_auc_pr > 0 means the model beats seasonal climatology.")
    print("=" * 100)
    cols = ["model", "horizon", "n", "base_rate", "AUC_PR", "ROC_AUC", "Brier",
            "precision_at_k", "lift", "skill_auc_pr"]
    print(results[cols].round(3).to_string(index=False))

    beat = results[(results["skill_auc_pr"] > 0) & (~results["model"].isin(BASELINES))]
    if beat.empty:
        print("\nNOTE: no model beat seasonal climatology. That is a legitimate,")
        print("reportable finding -- state it plainly rather than hiding it.")


if __name__ == "__main__":
    main()
