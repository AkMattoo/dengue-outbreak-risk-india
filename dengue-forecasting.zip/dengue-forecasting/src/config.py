"""Central configuration for the dengue outbreak-risk pipeline.

Every tunable setting lives here so a reviewer can see the whole design in one
place.

PROBLEM FRAMING
---------------
EpiClim is built from IDSP *outbreak reports*, not routine surveillance counts:
1,698 dengue records across 14 years and 345 districts, a median of 3 records
per district. There is no continuous case-count series to forecast.

What the data does support is an occurrence question. Aggregated to state x
month, a complete grid has 5,712 cells, 12.7% of which carry at least one
reported outbreak. So the target is:

    Will state S report a dengue outbreak in month t+h?

This is a probabilistic classification problem, evaluated against a seasonal
climatology baseline. Framing the question to match what the data can answer --
rather than forcing a case-count model onto event records -- is a deliberate
design decision, not a fallback.
"""
from pathlib import Path

# --------------------------------------------------------------- paths
ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
RAW = DATA / "raw"
EPICLIM_DIR = RAW / "epiclim"
DATAGOVIN = RAW / "datagovin"
INTERIM = DATA / "interim"
PROCESSED = DATA / "processed"
FIGURES = ROOT / "reports" / "figures"
MODELS = ROOT / "models"

for _p in (RAW, EPICLIM_DIR, DATAGOVIN, INTERIM, PROCESSED, FIGURES, MODELS):
    _p.mkdir(parents=True, exist_ok=True)

EPICLIM_FILE = EPICLIM_DIR / "EpiClim_Final_data.csv"

# --------------------------------------------------- scope of the analysis
DISEASE_PATTERN = "dengue"        # matched case-insensitively in the Disease column
SPATIAL_UNIT = "state"            # district-level is far too sparse -- see README
TIME_FREQ = "MS"                  # month start
START_DATE = "2009-01-01"
END_DATE = "2022-12-01"

# Years with obviously disrupted surveillance. Kept in the data but flagged, so
# the model can learn that reporting behaviour changed rather than treating the
# drop as a real decline in disease.
COVID_YEARS = (2020, 2021)

# --------------------------------------------------------------- modelling
HORIZONS = [1, 2, 3]              # predict outbreak occurrence 1, 2, 3 months ahead
LAGS = [1, 2, 3, 6, 12]
ROLLING_WINDOWS = [3, 6, 12]
CLIMATE_LAGS = [1, 2, 3]          # Aedes breeding responds to rain/heat with a lag
N_TEST_YEARS = 3                  # walk-forward: hold out the final N years
MIN_ACTIVE_MONTHS = 8             # drop states that almost never report anything
RANDOM_SEED = 42

# ----------------------------------------------------------------- sources
EPICLIM_ZENODO = "https://zenodo.org/records/14580510"
EPICLIM_PAPER = "https://iopscience.iop.org/article/10.1088/2752-5309/ae30f6"
IDSP_PORTAL = "https://idsp.mohfw.gov.in/"
DATA_GOV_IN_SEARCH = (
    "https://www.data.gov.in/search?title=dengue&type=resources&sortby=_score"
)
OPENMETEO_ARCHIVE_URL = "https://archive-api.open-meteo.com/v1/archive"

# Reference files
POPULATION_FILE = RAW / "state_population.csv"     # state,population,density,growth_rate
COORDS_FILE = RAW / "state_coords.csv"             # state,lat,lon (derived from EpiClim)
CLIMATE_FILE = PROCESSED / "climate_monthly.csv"   # state,date,temp/precip/humidity
