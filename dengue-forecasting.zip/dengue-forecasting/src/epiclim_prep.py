"""Stage 1 -- EpiClim outbreak records -> a complete state x month panel.

Run:  python -m src.epiclim_prep

Input : data/raw/epiclim/EpiClim_Final_data.csv
Output: data/processed/outbreak_panel.csv
        columns -> state, date, n_outbreaks, cases, deaths, outbreak (0/1)

THE CENTRAL MODELLING DECISION
------------------------------
EpiClim holds one row per *reported outbreak*. A state-month with no row is
therefore absent from the file entirely. Building the complete grid and filling
those gaps with zero is what turns an event log into a panel that can be
modelled.

That fill carries an assumption worth stating plainly, here and in the report:
a zero means "no outbreak was REPORTED", not "no outbreak occurred". States
with stronger surveillance report more, so the target partly measures
surveillance capacity. This is presence-only data with reporting bias, and no
amount of modelling removes that.
"""
from __future__ import annotations

import sys

import numpy as np
import pandas as pd

from src import config
from src.cleaning import clean_state

# Dengue is recorded under several spellings and in co-infection labels
# ('Dengue And Chikungunya', 'Dengue/Chikungunya', 'Suspected Dengue', ...).
# A substring match keeps all of them; the alternative -- exact match on
# 'Dengue' -- silently discards about 5% of the dengue records.
DISEASE_COL = "Disease"


def load_raw() -> pd.DataFrame:
    if not config.EPICLIM_FILE.exists():
        sys.exit(
            f"\nMissing {config.EPICLIM_FILE}\n"
            f"Download Final_data.csv from {config.EPICLIM_ZENODO}\n"
            f"and save it there.\n"
        )
    df = pd.read_csv(config.EPICLIM_FILE)
    df = df.drop(columns=[c for c in df.columns if c.startswith("Unnamed")])
    print(f"loaded {len(df):,} EpiClim records, {df[DISEASE_COL].nunique()} disease labels")
    return df


def filter_dengue(df: pd.DataFrame) -> pd.DataFrame:
    mask = df[DISEASE_COL].str.contains(config.DISEASE_PATTERN, case=False, na=False)
    den = df[mask].copy()
    labels = den[DISEASE_COL].value_counts()
    print(f"\n{len(den):,} dengue-related records under {len(labels)} labels:")
    print(labels.head(10).to_string())

    # Co-infection records are kept but flagged: they are genuine dengue
    # reports, though the case counts are shared with another disease.
    den["is_coinfection"] = den[DISEASE_COL].str.contains(
        "and |/|chikungunya|malaria", case=False, na=False
    ) & ~den[DISEASE_COL].str.strip().str.lower().isin(
        ["dengue", "dengue fever", "suspected dengue"]
    )
    print(f"{int(den['is_coinfection'].sum())} co-infection records flagged")
    return den


def clean_records(den: pd.DataFrame) -> pd.DataFrame:
    den["state"] = den["state_ut"].map(clean_state)
    unmapped = den.loc[den["state"].isna(), "state_ut"].unique()
    if len(unmapped):
        print(f"dropped unmappable state names: {list(unmapped)}")
    den = den.dropna(subset=["state"])

    # 'Cases' arrives as text and contains at least one malformed value ('3/1').
    den["cases"] = pd.to_numeric(den["Cases"], errors="coerce")
    n_bad = int(den["cases"].isna().sum())
    if n_bad:
        print(f"{n_bad} unparseable case counts set to NaN "
              f"(the outbreak still counts as an event)")
    den["deaths"] = pd.to_numeric(den["Deaths"], errors="coerce")

    den["date"] = pd.to_datetime(
        dict(year=den["year"], month=den["mon"], day=1), errors="coerce"
    )
    den = den.dropna(subset=["date"])
    den = den[(den["date"] >= config.START_DATE) & (den["date"] <= config.END_DATE)]
    return den


def build_grid(den: pd.DataFrame) -> pd.DataFrame:
    """Event log -> complete state x month grid, zero-filled."""
    agg = den.groupby(["state", "date"]).agg(
        n_outbreaks=("cases", "size"),
        cases=("cases", "sum"),
        deaths=("deaths", "sum"),
        n_districts=("district", "nunique"),
    ).reset_index()

    states = sorted(den["state"].unique())
    months = pd.date_range(config.START_DATE, config.END_DATE, freq=config.TIME_FREQ)
    grid = pd.MultiIndex.from_product([states, months], names=["state", "date"])

    panel = (agg.set_index(["state", "date"])
                .reindex(grid, fill_value=0)
                .reset_index())
    panel["outbreak"] = (panel["n_outbreaks"] > 0).astype(int)

    print(f"\ngrid: {len(states)} states x {len(months)} months = {len(panel):,} cells")
    print(f"cells with a reported outbreak: {panel['outbreak'].mean():.1%}")
    return panel


def drop_silent_states(panel: pd.DataFrame) -> pd.DataFrame:
    """Remove states that essentially never report.

    With only a handful of positive months there is nothing to learn, and
    including them inflates the apparent class imbalance.
    """
    active = panel.groupby("state")["outbreak"].sum()
    keep = active[active >= config.MIN_ACTIVE_MONTHS].index
    dropped = sorted(set(active.index) - set(keep))
    print(f"\nkeeping {len(keep)}/{len(active)} states with >= "
          f"{config.MIN_ACTIVE_MONTHS} months of reported outbreaks")
    if dropped:
        print(f"dropped (near-silent): {dropped}")
    return panel[panel["state"].isin(keep)].copy()


def quality_report(panel: pd.DataFrame, den: pd.DataFrame) -> None:
    print("\n" + "=" * 66)
    print("DATA QUALITY REPORT")
    print("=" * 66)
    print(f"states           : {panel['state'].nunique()}")
    print(f"months           : {panel['date'].nunique()}")
    print(f"cells            : {len(panel):,}")
    print(f"positive rate    : {panel['outbreak'].mean():.1%}")
    print(f"source districts : {den['district'].nunique()}")

    print("\nreported outbreaks by calendar month "
          "(expect a monsoon / post-monsoon peak):")
    bym = panel.groupby(panel["date"].dt.month)["n_outbreaks"].sum()
    print(bym.to_string())
    peak = int(bym.idxmax())
    print(f"peak month = {peak} "
          f"({'PASS' if peak in (7, 8, 9, 10) else 'CHECK THIS'})")

    print("\nreported outbreaks by year (note the 2020-21 COVID disruption):")
    print(panel.groupby(panel["date"].dt.year)["n_outbreaks"].sum().to_string())

    print("\nmonths with a reported outbreak, by state:")
    print(panel.groupby("state")["outbreak"].sum()
          .sort_values(ascending=False).to_string())
    print("\nNOTE: this ranking reflects surveillance intensity as much as")
    print("disease burden. Treat it as reporting behaviour, not incidence.")


def main() -> None:
    raw = load_raw()
    den = filter_dengue(raw)
    den = clean_records(den)
    panel = build_grid(den)
    panel = drop_silent_states(panel)
    quality_report(panel, den)

    out = config.PROCESSED / "outbreak_panel.csv"
    panel.to_csv(out, index=False)
    print(f"\nwrote {out}  shape={panel.shape}")


if __name__ == "__main__":
    main()
