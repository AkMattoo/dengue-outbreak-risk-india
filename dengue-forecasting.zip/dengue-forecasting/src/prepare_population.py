"""Convert the Census 2011 Table 2A extract into the reference file the
feature pipeline expects.

Run:  python -m src.prepare_population

Input : data/raw/census_Table_2A_State_Uts.csv
        (Category, India/State/Union Territory, Population 2011,
         Decadal Population Growth Rate - 2001-2011,
         Population Density (per sq.km) - 2011)

Output: data/raw/state_population.csv
        columns -> state, population, density, growth_rate

Two things this handles that a plain read_csv would not:

1. The 'India' row is a national aggregate and must be dropped, exactly like
   the 'Total' rows in the dengue tables.
2. Dadra & Nagar Haveli and Daman & Diu were separate UTs in 2011 but merged
   into a single UT in 2020. The dengue tables use whichever name applied at
   the time, so the two are summed here and given the merged name. Population
   is additive; density is recomputed as a population-weighted average, since
   averaging two densities directly would be wrong.
"""
from __future__ import annotations

import sys

import pandas as pd

from src import config
from src.cleaning import clean_state

SRC = config.RAW / "census_Table_2A_State_Uts.csv"
OUT = config.POPULATION_FILE          # data/raw/state_population.csv

MERGED_UT = "Dadra and Nagar Haveli and Daman and Diu"


def main() -> None:
    if not SRC.exists():
        sys.exit(f"Missing {SRC}. Save the Census Table 2A CSV there first.")

    df = pd.read_csv(SRC)
    df.columns = [c.strip() for c in df.columns]

    name_col = "India/State/Union Territory"
    df = df.rename(columns={
        name_col: "raw_name",
        "Population 2011": "population",
        "Population Density (per sq.km) - 2011": "density",
        "Decadal Population Growth Rate - 2001-2011": "growth_rate",
    })

    # Drop the national aggregate row before anything else.
    n_before = len(df)
    df = df[df["Category"].str.strip().str.lower() != "india"]
    print(f"dropped {n_before - len(df)} aggregate row(s)")

    # Normalise names through the SAME alias map the dengue parser uses, so the
    # merge key is guaranteed to match.
    df["state"] = df["raw_name"].map(clean_state)

    unmapped = df.loc[df["state"].isna(), "raw_name"].tolist()
    if unmapped:
        print(f"could not clean: {unmapped}")

    df = df.dropna(subset=["state"])
    for c in ("population", "density", "growth_rate"):
        df[c] = pd.to_numeric(df[c], errors="coerce")

    # Report which raw names were rewritten, so the mapping is auditable.
    changed = df[df["raw_name"].str.strip() != df["state"]]
    if len(changed):
        print("\nname changes applied:")
        for _, r in changed.iterrows():
            print(f"  {r['raw_name']:32s} -> {r['state']}")

    # Combine the two former UTs into their present-day merged form.
    if (df["state"] == MERGED_UT).sum() > 1:
        part = df[df["state"] == MERGED_UT]
        pop = part["population"].sum()
        merged = pd.DataFrame([{
            "state": MERGED_UT,
            "population": pop,
            # weighted by population -- a plain mean of two densities is wrong
            "density": (part["density"] * part["population"]).sum() / pop,
            "growth_rate": (part["growth_rate"] * part["population"]).sum() / pop,
        }])
        df = pd.concat([df[df["state"] != MERGED_UT], merged], ignore_index=True)
        print(f"\nmerged {len(part)} rows into '{MERGED_UT}' "
              f"(population {pop:,.0f})")

    out = (df[["state", "population", "density", "growth_rate"]]
           .dropna(subset=["population"])
           .sort_values("state")
           .reset_index(drop=True))
    out["population"] = out["population"].astype("int64")
    out["density"] = out["density"].round(1)

    assert not out["state"].duplicated().any(), "duplicate states in output"

    out.to_csv(OUT, index=False)
    print(f"\nwrote {OUT}  ({len(out)} states/UTs, "
          f"total population {out['population'].sum():,})")
    print(out.to_string(index=False))


if __name__ == "__main__":
    main()
